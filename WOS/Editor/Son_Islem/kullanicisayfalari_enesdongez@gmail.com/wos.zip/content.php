		<td id="littleheader" colspan="6" height="10%" style="word-wrap:break-word;  width:100%;">
<div id="littleheader" style="height:100%; width:100%;">
	<?php include 'littleheader.php'; ?>
</div>
</td>
</tr>
		 <tr>
	
<td id="content1" valign="top" colspan="3" style="word-wrap:break-word; width:50%;">
                <div id="content1" style="height:100%; width:100%;">
                <?php include 'content1.php'; ?>
                </div>
                </td>
                <td id="content2" colspan="3" valign="top" style="word-wrap:break-word; width:50%;">
                <div id="content2" style="height:100%; width:100%;">
                <?php include 'content2.php'; ?>
                </div>
                </td> 
				</tr>
				
					<tr height="20%">
            <td id="bar1" width="20%">
			<div id="bar1" style="width:100%; height:100%;">
			 <?php include 'bar1.php'; ?>
			</div>
			</td>
			<td id="bar2" width="20%">
			<div id="bar2" style="width:100%; height:100%;">
			 <?php include 'bar2.php'; ?>
			</div>
			</td>
			<td id="bar3" colspan="2" width="20%">
			<div id="bar3" style="width:100%; height:100%;">
			 <?php include 'bar3.php'; ?>
			</div>
			</td>
			<td id="bar4" width="20%">
			<div id="bar4" style="width:100%; height:100%;">
			 <?php include 'bar4.php'; ?>
			</div>
			</td>
            <td id="bar5" width="20%">
			<div id="bar5" style="width:100%; height:100%;">
			 <?php include 'bar5.php'; ?>
			</div>
			</td>
