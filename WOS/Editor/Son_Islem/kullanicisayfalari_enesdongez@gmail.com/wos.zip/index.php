<html>
<head>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script><style>
body{
                    background: url(414.jpg);
                    background-repeat: no-repeat;
                    background-size: 100% 100%;
                    background-attachment: fixed;
                    background-color:#ffffff;
margin:0;
padding:0;
}
</style>
</head>
<body>
<center><table class="data" border="0px" id="data" cellspacing="0" height="100%" width="80%"> 
        <tr height="30%">
            <td id="header" colspan="6">
			<div id="header" style="width:100%; height:100%;">
                  <?php include 'header.php'; ?>
                </div>
			</td>
        </tr>
	 <tr>
			<div>
            <?php

                $sayfalar_klasor='./';

                if(!empty($_GET['sayfa'])){
                    $sayfalar=scandir($sayfalar_klasor,0);
                    unset($sayfalar[0],$sayfalar[1]);
                    
                $sayfa=$_GET['sayfa'];
                if(in_array($sayfa.'.php', $sayfalar)){
                    include $sayfa.'.php'; 
                    
                    
                }
                else{
                    echo 'Aradýðýnýz sayfa bulunamadý';
                }
                  
              
                }
                else{
                    include 'content.php';
                }
                ?>
			</div>
   
        </tr>
   </table>
</body>
</html>