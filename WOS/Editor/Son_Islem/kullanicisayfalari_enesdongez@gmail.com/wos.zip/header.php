<?php $header1_yazi31="Enes Döngez";$header1_arkaplan31="AB2567";$header1_resim31="dsd.jpg";$header1_yazim_fontu31="Times New Roman";$header1_yazim_renk31="AB2567";$header1_resim_daire31=" ";$header1_resim_genislik31="200";$header1_resim_yükseklik31="255";$header1_resim_golge31="-webkit-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.75); -moz-box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.75); box-shadow: 10px 10px 5px 0px rgba(0,0,0,0.75);"; ?>
<?php echo '<div style="background-color:'.$header1_arkaplan31.';">'; ?>
<center>
<table border="0px" cellpadding="20" style="word-wrap:break-word;">
<tr>
<td>
<center>
<?php echo '<a href="?sayfa=content"><img src="resimler/'.$header1_resim31.'" width="'.$header1_resim_genislik31.'px" height="'.$header1_resim_yükseklik31.'px" style="'.$header1_resim_daire31.' '.$header1_resim_golge31.'"/></a>'; ?>
</center>
</td></tr><tr>
<td style="word-wrap:break-word;">
<center>
<?php echo '<a href="?sayfa=content" style="text-decoration:none;"><h1 style="font-family: '.$header1_yazim_fontu31.'; color:'.$header1_yazim_renk31.';">'.$header1_yazi31.'</h1></a>'; ?>
</center>
</td>
</tr>
</table>
</center>
</div>