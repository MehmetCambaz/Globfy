<?php $content4_arkaplan2="AB2567";$content4_resimidhazir2="'CWVAD'";$content4_resimidhazir22="CWVAD"; ?>
<script> var a=2; function aRefleshYXJPF(imageName) { document.getElementById(imageName).src="resimler/galeri_YXJPF/ajk"+a+".png";
a++;
if(a>4)a=1;
}
function aRefleshYXJPF2(imageName)
{
document.getElementById(imageName).src="resimler/galeri_YXJPF/ajk"+a+".png";
a--;
if(a<1)a=4;
}

</script>
<?php echo '<div style="background-color:'.$content4_arkaplan2.';">'; ?>
<center>
<table border="0">
<tr>
<td><?php echo '<input type="button" onClick="aRefleshYXJPF('.$content4_resimidhazir22.')"  value="<" style=" float:left;  margin:2 0 0 0; height:300;  background-color:#1A263A; color:white; border:0px solid black; font-size:60px; font-family:Calibri;">'; ?></td>
<td><?php echo '<img src="resimler/galeri_YXJPF/ajk1.png" name="'.$content4_resimidhazir22.'" id="'.$content4_resimidhazir22.'" style="float:left; margin:20 15 20 15" width="600px" height="300px"></td>'; ?>
<td><?php echo '<input type="button" onClick="aRefleshYXJPF2('.$content4_resimidhazir22.')" value=">" style=" float:left;  margin:2 0 0 0; height:300;  background-color:#1A263A; color:white; border:0px solid black; font-size:60px; font-family:Calibri;">'; ?></td>
</tr>
</table>
</center>
</div>
</div>