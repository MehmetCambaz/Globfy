<?php $content2_yazim5="asdddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd";$content2_arkaplan5="AB8478"; ?>
<?php echo '<div style="background-color:'.$content2_arkaplan5.'; word-wrap:break-word; text-align:center;">'; ?>
<center>
<table border="0px" cellpadding="20">
<tr>
<td>
<h3>
<?php echo '<div style="word-wrap:break-word;"><h2>'.$content2_yazim5.'</h2></div>'; ?>
</h3>
</td>
</tr>
</table>
</center>
</div>
