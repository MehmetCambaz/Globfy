<td id="content_x" colspan="4" rowspan="4" valign="top" style="word-break:break-all; width:100%;">  
              <div id="content_x">          
              <?php include 'content_x.php'; ?>
              </div>         
            </td>