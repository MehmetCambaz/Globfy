<td id="content_xxx" colspan="4" rowspan="4" valign="top" style="word-break:break-all; width:100%;">  
              <div id="content_xxx">          
              <?php include 'content_xxx.php'; ?>
              </div>         
            </td>