<td id="content_xx" colspan="4" rowspan="4" valign="top" style="word-break:break-all; width:100%;">  
              <div id="content_xx">          
              <?php include 'content_xx.php'; ?>
              </div>         
            </td>