<?php $header2_yazi1="x";$header2_yazi21="xx";$header2_yazi31="xxx";$header2_yazi41="Web Site Oluşturma Sistemi";$header2_arkaplan1="000000";$header2_resim1="a4.jpg"; ?>
<?php echo '<div style="background-color:'.$header2_arkaplan1.';">'; ?>
<center>
<table border="0px" cellpadding="20">
<td> <?php echo '<a href="?sayfa=content"><img src="resimler/'.$header2_resim1.'" width="250px" height="250px" style=""/></a>'; ?>   </td>
<td> <?php echo '<h3>'.$header2_yazi41.'</h3>'; ?> </td>
<td> </td>
<td> </td>
<td> <?php echo '<h3><a href="?sayfa='.$header2_yazi1.'" style="text-decoration:none; color:white; border:1px solid black; padding:10;">'.$header2_yazi1.'</a></h3>'; ?>   </td>
<td> <?php echo '<h3><a href="?sayfa='.$header2_yazi21.'" style="text-decoration:none; color:white; border:1px solid black; padding:10;">'.$header2_yazi21.'</a></h3>'; ?>   </td>
<td> <?php echo '<h3><a href="?sayfa='.$header2_yazi31.'" style="text-decoration:none; color:white; border:1px solid black; padding:10;">'.$header2_yazi31.'</a></h3>'; ?>   </td>
</table>
</center>
</div>