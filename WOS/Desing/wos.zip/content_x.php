<?php $content5_yazi4="saddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd";$content5_resim14="a2.jpg";$content5_arkaplan4="1D1BAB";$content5_yazi_rengi4="9EAB61";$content5_resim24="a3.jpg"; ?>
<?php echo '<div style="background-color:'.$content5_arkaplan4.';">'; ?>
<center>
<table border="0px" cellpadding="20">
<tr>
<td>
<marquee scrollamount="3"  direction="down">

<?php echo '<img src="resimler/'.$content5_resim14.'" height="200" width="200">'; ?>

</marquee>
</td>
<td style="text-align:center; width:210px;">

<?php echo '<p style="word-wrap:break-word; width:250px; margin:5 5 5 5; color:'.$content5_yazi_rengi4.';">'.$content5_yazi4.'</p>'; ?>
</td>
<td>
<marquee scrollamount="3"  direction="down">

<?php echo '<img src="resimler/'.$content5_resim24.'" height="200" width="200">'; ?>

</marquee>
</td>
</tr>
</table>
</center>
</div>
</div>