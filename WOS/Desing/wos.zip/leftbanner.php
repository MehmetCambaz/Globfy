<?php $leftbanner4_yazi3="adasdasdasdasdasd";$leftbanner4_arkaplan3="AB2567";$leftbanner4_resim3="a2.jpg"; ?>
<?php echo '<div style="background-color:'.$leftbanner4_arkaplan3.'">'; ?>
<center>
<table border="0px" cellpadding="20">
<tr>
<td>
<?php echo '<img src="resimler/'.$leftbanner4_resim3.'" width="200px" height="200px" style=""/>'; ?>
</td>
</tr>
<tr>
<td>
<?php echo '<h3>'.$leftbanner4_yazi3.'</h3>'; ?>
</td>
</tr>
</table>
</center>
</div>